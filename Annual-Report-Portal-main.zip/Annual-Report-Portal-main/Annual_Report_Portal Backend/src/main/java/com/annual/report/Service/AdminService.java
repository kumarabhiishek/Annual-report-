package com.annual.report.Service;

public interface AdminService {

     boolean validateAdmin(String username, String password);
}
